import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UserF extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField ID;
	private JTextField Name;
	private JTextField Password;
	private JTextField Address;
	private JTextField Yb;
	private JTextField Tel;
	private JTextField BZ;

	public UserF(JTable jt) {
		setTitle("\u5BA2\u6237");
		setBounds(100, 100, 441, 320);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("\u5BA2\u6237ID\uFF1A");
			lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			lblNewLabel.setBounds(56, 48, 54, 15);
			contentPanel.add(lblNewLabel);
		}
		{
			ID = new JTextField();
			ID.setBounds(115, 44, 66, 21);
			contentPanel.add(ID);
			ID.setColumns(10);
		}
		{
			Name = new JTextField();
			Name.setColumns(10);
			Name.setBounds(284, 46, 66, 21);
			contentPanel.add(Name);
		}
		{
			JLabel label = new JLabel("\u59D3\u540D\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(225, 50, 54, 15);
			contentPanel.add(label);
		}
		{
			Password = new JTextField();
			Password.setColumns(10);
			Password.setBounds(115, 92, 66, 21);
			contentPanel.add(Password);
		}
		{
			JLabel label = new JLabel("\u5BC6\u7801\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(56, 96, 54, 15);
			contentPanel.add(label);
		}
		{
			Address = new JTextField();
			Address.setColumns(10);
			Address.setBounds(283, 94, 66, 21);
			contentPanel.add(Address);
		}
		{
			JLabel label = new JLabel("\u5730\u5740\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(224, 98, 54, 15);
			contentPanel.add(label);
		}
		{
			Yb = new JTextField();
			Yb.setColumns(10);
			Yb.setBounds(116, 140, 66, 21);
			contentPanel.add(Yb);
		}
		{
			JLabel label = new JLabel("\u90AE\u7F16\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(57, 144, 54, 15);
			contentPanel.add(label);
		}
		{
			Tel = new JTextField();
			Tel.setColumns(10);
			Tel.setBounds(284, 141, 66, 21);
			contentPanel.add(Tel);
		}
		{
			JLabel label = new JLabel("\u7535\u8BDD\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(225, 145, 54, 15);
			contentPanel.add(label);
		}
		{
			BZ = new JTextField();
			BZ.setColumns(10);
			BZ.setBounds(210, 188, 66, 21);
			contentPanel.add(BZ);
		}
		{
			JLabel lblid = new JLabel("\u6240\u5B9A\u62A5\u7EB8ID\uFF1A");
			lblid.setHorizontalAlignment(SwingConstants.RIGHT);
			lblid.setBounds(81, 192, 124, 15);
			contentPanel.add(lblid);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton serch = new JButton("\u67E5\u627E");
				serch.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						User a = new User(ID.getText(),Name.getText(), Password.getText(), Address.getText(), Yb.getText(), Tel.getText(),BZ.getText());
						User.serch(jt, a);
					}
				});
				serch.setActionCommand("OK");
				buttonPane.add(serch);
				getRootPane().setDefaultButton(serch);
			}
			{
				JButton add = new JButton("\u6DFB\u52A0");
				add.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						User a = new User(ID.getText(),Name.getText(), Password.getText(), Address.getText(), Yb.getText(), Tel.getText(),BZ.getText());
						if(User.add(a)) JOptionPane.showMessageDialog(null, "���ӳɹ�");
						else JOptionPane.showMessageDialog(null, "����ʧ��");
						User.fresh(jt);
					}
				});
				buttonPane.add(add);
			}
			{
				JButton del = new JButton("\u5220\u9664");
				del.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(User.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
						else JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ������Ƿ���д��ȷ ");
						User.fresh(jt);
					}
				});
				buttonPane.add(del);
			}
			{
				JButton back = new JButton("\u8FD4\u56DE");
				back.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				back.setActionCommand("Cancel");
				buttonPane.add(back);
			}
		}
	}

}
