import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;




public class Gys {
	public String ID,Name,Bzm,Area,Tel,Mail;
	Gys(String id,String name,String bzm,String area,String tel,String mail){
		ID = id;
		Name = name;
		Bzm = bzm;
		Area = area;
		Tel = tel;
		Mail = mail;
	}
	public static void fresh(JTable jt){
		Object[][] tempp = null;	
		try {
			SQL db = new SQL();
			ResultSet rs = db.Do("SELECT * FROM C_GYS");
			int i=0;
			while(rs.next()) i++;
			rs = db.Do("SELECT * FROM C_GYS");
			tempp = new Object[i][6];
			i=0;
			while(rs.next()){
				for(int y=0;y<6;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"ID", "\u4F9B\u5E94\u5546\u540D", "\u62A5\u7EB8\u540D", "\u5730\u533A", "\u7535\u8BDD\u53F7\u7801", "\u90AE\u4EF6"
				}
		));
	}
	static boolean add(Gys temp){
		try {
			SQL db = new SQL();
			db.Se("INSERT INTO C_GYS VALUES ('"+temp.Name+"','"+temp.Bzm+"','"+temp.Area+"','"+temp.Tel+"','"+temp.Mail+"');");
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean del(String ID){
		try {
			SQL db = new SQL();
			db.Se("DELETE FROM C_GYS WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public static void serch(JTable jt,Gys temp){
		Object[][] tempp = null;	
		try {
			SQL db = new SQL();
			String sqql = "";
			if(temp.ID.equals("")) sqql = "SELECT * FROM C_GYS WHERE NAME LIKE '%"+temp.Name+"%' AND BZM LIKE '%"+temp.Bzm+"%' AND AREA LIKE '%"+temp.Area+"%' AND TEL LIKE '%"+temp.Tel+"%' AND MAIL LIKE '%"+temp.Mail+"%'";
			else sqql = "SELECT * FROM C_GYS WHERE ID = "+temp.ID;
			ResultSet rs = db.Do(sqql);
			int i=0;
			while(rs.next()) i++;
			rs = db.Do(sqql);
			tempp = new Object[i][6];
			i=0;
			while(rs.next()){
				for(int y=0;y<6;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"ID", "\u4F9B\u5E94\u5546\u540D", "\u62A5\u7EB8\u540D", "\u5730\u533A", "\u7535\u8BDD\u53F7\u7801", "\u90AE\u4EF6"
				}
		));
	}
}
