import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;




public class User {
	public String ID,Name,Password,Address,Yb,Tel,Bz;
	User(String id,String name,String password,String address,String yb,String tel,String bz){
		ID = id;
		Name = name;
		Password = password;
		Address = address;
		Yb = yb;
		Tel = tel;
		Bz = bz;
	}
	public static void fresh(JTable jt){
		Object[][] tempp = null;	
		try {
			SQL db = new SQL();
			ResultSet rs = db.Do("SELECT * FROM USERR");
			int i=0;
			while(rs.next()) i++;
			rs = db.Do("SELECT * FROM USERR");
			tempp = new Object[i][7];
			i=0;
			while(rs.next()){
				for(int y=0;y<7;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"ID", "����", "����", "��ַ", "�ʱ�", "�绰","������ֽ"
				}
		));
	}
	static boolean add(User temp){
		try {
			SQL db = new SQL();
			db.Se("INSERT INTO USERR VALUES ('"+temp.Name+"','"+temp.Password+"','"+temp.Address+"','"+temp.Yb+"','"+temp.Tel+"',"+temp.Bz+")");
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean del(String ID){
		try {
			SQL db = new SQL();
			db.Se("DELETE FROM USERR WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public static void serch(JTable jt,User temp){
		Object[][] tempp = null;	
		try {
			SQL db = new SQL();
			String sqql = "";
			if(temp.ID.equals("")) sqql = "SELECT USERR.ID,USERR.NAME,USERR.PASSWORD,USERR.ADDRESS,USERR.YB,USERR.TEL,NEWSPAPER.NAME FROM USERR JOIN NEWSPAPER ON USERR.BZ = NEWSPAPER.ID WHERE USERR.ID LIKE '%"+temp.ID +"%' AND USERR.NAME LIKE '%"+temp.Name+"%' AND USERR.PASSWORD LIKE '%"+temp.Password+"%' AND USERR.ADDRESS LIKE '%"+temp.Address+"%' AND USERR.YB LIKE '%"+temp.Yb+"%' AND USERR.TEL LIKE '%"+temp.Tel+"%' AND NEWSPAPER.NAME LIKE '%"+temp.Bz+"%'";
			else sqql = "SELECT * FROM USERR WHERE ID = "+temp.ID;
			ResultSet rs = db.Do(sqql);
			int i=0;
			while(rs.next()) i++;
			rs = db.Do(sqql);
			tempp = new Object[i][7];
			i=0;
			while(rs.next()){
				for(int y=0;y<7;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"ID", "����", "����", "��ַ", "�ʱ�", "�绰","������ֽ"
				}
		));
	}
}
