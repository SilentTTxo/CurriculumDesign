import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Newspaper extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField ID;
	private JTextField Name;
	private JTextField Type;
	private JTextField Area;
	private JTextField Cbs;
	private JTextField Jdyj;
	private JTextField Jhl;
	private JTextField Kc;
	private JTextField GID;

	public Newspaper(JTable jt) {
		setTitle("\u62A5\u7EB8");
		setBounds(100, 100, 555, 291);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u62A5\u7EB8ID\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(65, 34, 54, 15);
		contentPanel.add(lblNewLabel);
		
		ID = new JTextField();
		ID.setBounds(118, 31, 66, 21);
		contentPanel.add(ID);
		ID.setColumns(10);
		
		JLabel label = new JLabel("\u62A5\u7EB8\u540D\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(203, 34, 54, 15);
		contentPanel.add(label);
		
		Name = new JTextField();
		Name.setColumns(10);
		Name.setBounds(256, 31, 66, 21);
		contentPanel.add(Name);
		
		JLabel lblNewLabel_1 = new JLabel("\u6CE8\uFF1A\u6DFB\u52A0\u4E0D\u586BID\uFF0C\u5220\u9664\u5FC5\u586B\uFF0C\u67E5\u8BE2\u53EF\u586B");
		lblNewLabel_1.setBounds(21, 9, 236, 15);
		contentPanel.add(lblNewLabel_1);
		
		JLabel label_1 = new JLabel("\u7C7B\u522B\uFF1A");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(341, 34, 54, 15);
		contentPanel.add(label_1);
		
		Type = new JTextField();
		Type.setColumns(10);
		Type.setBounds(394, 31, 66, 21);
		contentPanel.add(Type);
		
		JLabel label_2 = new JLabel("\u5730\u533A\uFF1A");
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setBounds(65, 91, 54, 15);
		contentPanel.add(label_2);
		
		Area = new JTextField();
		Area.setColumns(10);
		Area.setBounds(118, 88, 66, 21);
		contentPanel.add(Area);
		
		JLabel label_3 = new JLabel("\u51FA\u7248\u793E\uFF1A");
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setBounds(203, 149, 54, 15);
		contentPanel.add(label_3);
		
		Cbs = new JTextField();
		Cbs.setColumns(10);
		Cbs.setBounds(256, 146, 66, 21);
		contentPanel.add(Cbs);
		
		JLabel label_4 = new JLabel("\u5B63\u5EA6\u7EA6\u4EF7\uFF1A");
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setBounds(332, 88, 65, 15);
		contentPanel.add(label_4);
		
		Jdyj = new JTextField();
		Jdyj.setColumns(10);
		Jdyj.setBounds(396, 85, 66, 21);
		contentPanel.add(Jdyj);
		
		Jhl = new JTextField();
		Jhl.setColumns(10);
		Jhl.setBounds(118, 146, 66, 21);
		contentPanel.add(Jhl);
		
		JLabel label_5 = new JLabel("\u8FDB\u8D27\u91CF\uFF1A");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setBounds(65, 149, 54, 15);
		contentPanel.add(label_5);
		
		Kc = new JTextField();
		Kc.setColumns(10);
		Kc.setBounds(394, 146, 66, 21);
		contentPanel.add(Kc);
		
		JLabel label_6 = new JLabel("\u5E93\u5B58\uFF1A");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setBounds(341, 149, 54, 15);
		contentPanel.add(label_6);
		
		JLabel lblid = new JLabel("\u4F9B\u5E94\u5546ID\uFF1A");
		lblid.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid.setBounds(183, 94, 74, 15);
		contentPanel.add(lblid);
		
		GID = new JTextField();
		GID.setColumns(10);
		GID.setBounds(256, 91, 66, 21);
		contentPanel.add(GID);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			
			JButton btnNewButton_1 = new JButton("\u67E5\u627E");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					News a = new News(ID.getText(),Name.getText(), Type.getText(), Area.getText(), Cbs.getText(), GID.getText(),Jdyj.getText(),Jhl.getText(),Kc.getText());
					News.serch(jt, a);
				}
			});
			buttonPane.add(btnNewButton_1);
			{
				JButton okButton = new JButton("\u6DFB\u52A0");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						News a = new News("yo",Name.getText(), Type.getText(), Area.getText(), Cbs.getText(),GID.getText() ,Jdyj.getText(), Jhl.getText(), Kc.getText());
						if(News.add(a)) JOptionPane.showMessageDialog(null, "���ӳɹ�");
						else JOptionPane.showMessageDialog(null, "����ʧ��");
						News.fresh(jt);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			
			JButton btnNewButton = new JButton("\u5220\u9664");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(News.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
					else JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ������Ƿ���д��ȷ ");
					News.fresh(jt);
				}
			});
			buttonPane.add(btnNewButton);
			{
				JButton cancelButton = new JButton("\u8FD4\u56DE");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
