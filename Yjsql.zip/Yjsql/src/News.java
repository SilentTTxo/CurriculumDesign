import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;




public class News {
	public String ID,Name,Type,Area,Cbs,Gys,Jdyj,Jhl,Kc;
	News(String id,String name,String type,String area,String cbs,String gys,String jdyj,String jhl,String kc){
		ID = id;
		Name = name;
		Type = type;
		Area = area;
		Cbs = cbs;
		Gys = gys;
		Jdyj = jdyj;
		Jhl = jhl;
		Kc = kc;
	}
	public static void fresh(JTable jt){
		Object[][] tempp = null;	
		try {
			SQL db = new SQL();
			ResultSet rs = db.Do("SELECT * FROM NEWSPAPER");
			int i=0;
			while(rs.next()) i++;
			rs = db.Do("SELECT * FROM NEWSPAPER");
			tempp = new Object[i][9];
			i=0;
			while(rs.next()){
				for(int y=0;y<9;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"��ֽID", "����", "����", "����", "������", "��Ӧ��","����Լ��","������","���"
				}
		));
	}
	static boolean add(News temp){
		try {
			SQL db = new SQL();
			db.Se("INSERT INTO NEWSPAPER VALUES ('"+temp.Name+"','"+temp.Type+"','"+temp.Area+"','"+temp.Cbs+"',"+temp.Gys+",'"+temp.Jdyj+"','"+temp.Jhl+"','"+temp.Kc+"');");
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean del(String ID){
		try {
			SQL db = new SQL();
			db.Se("DELETE FROM NEWSPAPER WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public static void serch(JTable jt,News temp){
		Object[][] tempp = null;	
		try {
			SQL db = new SQL();
			String sqql = "";
			if(temp.ID.equals("")){
				sqql = "SELECT * FROM NEWSPAPER WHERE NAME LIKE '%"+temp.Name+"%' AND TYPE LIKE '%"+temp.Type+"%' AND AREA LIKE '%"+temp.Area+"%' AND CBS LIKE '%"+temp.Cbs+"%' AND JDYJ LIKE '%"+temp.Jdyj+"%' AND JHL LIKE '%"+temp.Jhl+"%' AND KC LIKE '%"+temp.Kc+"%'";
				if(!temp.Gys.equals("")) sqql+="AND GYS = "+temp.Gys;
			}
			else{
				sqql = "SELECT * FROM NEWSPAPER WHERE ID = "+temp.ID;
			}
			ResultSet rs = db.Do(sqql);
			int i=0;
			while(rs.next()) i++;
			rs = db.Do(sqql);
			tempp = new Object[i][9];
			i=0;
			while(rs.next()){
				for(int y=0;y<9;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"��ֽID", "����", "����", "����", "������", "��Ӧ��","����Լ��","������","���"
				}
		));
	}
}
