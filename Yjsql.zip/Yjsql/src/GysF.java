import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GysF extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField ID;
	private JTextField Name;
	private JTextField PName;
	private JTextField Area;
	private JTextField Tel;
	private JTextField Mail;

	public GysF(JTable jt) {
		setTitle("\u4F9B\u5E94\u5546");
		setBounds(100, 100, 450, 242);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("\u4F9B\u5E94\u5546ID\uFF1A");
			lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			lblNewLabel.setBounds(59, 31, 77, 15);
			contentPanel.add(lblNewLabel);
		}
		{
			ID = new JTextField();
			ID.setBounds(136, 28, 66, 21);
			contentPanel.add(ID);
			ID.setColumns(10);
		}
		{
			Name = new JTextField();
			Name.setColumns(10);
			Name.setBounds(295, 28, 66, 21);
			contentPanel.add(Name);
		}
		{
			JLabel label = new JLabel("\u4F9B\u5E94\u5546\u540D\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(235, 31, 60, 15);
			contentPanel.add(label);
		}
		{
			PName = new JTextField();
			PName.setColumns(10);
			PName.setBounds(136, 74, 66, 21);
			contentPanel.add(PName);
		}
		{
			JLabel label = new JLabel("\u62A5\u7EB8\u540D\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(76, 77, 60, 15);
			contentPanel.add(label);
		}
		{
			Area = new JTextField();
			Area.setColumns(10);
			Area.setBounds(295, 74, 66, 21);
			contentPanel.add(Area);
		}
		{
			JLabel label = new JLabel("\u5730\u533A\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(235, 77, 60, 15);
			contentPanel.add(label);
		}
		{
			Tel = new JTextField();
			Tel.setColumns(10);
			Tel.setBounds(136, 120, 66, 21);
			contentPanel.add(Tel);
		}
		{
			JLabel label = new JLabel("\u7535\u8BDD\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(76, 123, 60, 15);
			contentPanel.add(label);
		}
		{
			Mail = new JTextField();
			Mail.setColumns(10);
			Mail.setBounds(295, 120, 66, 21);
			contentPanel.add(Mail);
		}
		{
			JLabel label = new JLabel("\u90AE\u7BB1\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(235, 123, 60, 15);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6CE8\uFF1A\u6DFB\u52A0\u4E0D\u586BID\uFF0C\u5220\u9664\u5FC5\u586B\uFF0C\u67E5\u8BE2\u53EF\u586B");
			label.setBounds(33, 6, 236, 15);
			contentPanel.add(label);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton serch = new JButton("\u67E5\u627E");
				serch.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						Gys a = new Gys(ID.getText(),Name.getText(), PName.getText(), Area.getText(), Tel.getText(), Mail.getText());
						Gys.serch(jt, a);
					}
				});
				buttonPane.add(serch);
			}
			{
				JButton add = new JButton("\u589E\u52A0");
				add.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Gys a = new Gys("yo",Name.getText(), PName.getText(), Area.getText(), Tel.getText(), Mail.getText());
						if(Gys.add(a)) JOptionPane.showMessageDialog(null, "���ӳɹ�");
						else JOptionPane.showMessageDialog(null, "����ʧ��");
						Gys.fresh(jt);
					}
				});
				add.setActionCommand("OK");
				buttonPane.add(add);
				getRootPane().setDefaultButton(add);
			}
			{
				JButton del = new JButton("\u5220\u9664");
				del.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(Gys.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
						else JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ������Ƿ���д��ȷ ");
						Gys.fresh(jt);
					}
				});
				buttonPane.add(del);
			}
			{
				JButton back = new JButton("\u8FD4\u56DE");
				back.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				back.setActionCommand("Cancel");
				buttonPane.add(back);
			}
		}
	}

}
