

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQL {
	private String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";//������������
	private String connectionUrl = "jdbc:sqlserver://localhost:1433;" +
			   "databaseName=YJSQL;user=sa;password=a132132;";
	private Connection con;
	private Statement stmt ;
	SQL() throws Exception{
		Class.forName(driverName);
		con = DriverManager.getConnection(connectionUrl); //2���������ݿ�  
        System.out.println("���ݿ�ɹ����ӣ�"+con);  
        stmt = con.createStatement();
	}
	public void Close() throws SQLException{
		con.close();
	}
	public ResultSet Do(String sql) throws SQLException{
		return stmt.executeQuery(sql);
	}
	public ResultSet Do2(String sql) throws SQLException{
		return con.createStatement().executeQuery(sql);
	}
	public void Se(String sql) throws SQLException{
		stmt.execute(sql);
	}
}
