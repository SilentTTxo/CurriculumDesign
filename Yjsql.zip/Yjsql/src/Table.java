import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;


import java.awt.CardLayout;

public class Table extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Table frame = new Table();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Table() {
		setTitle("\u8BA2\u62A5\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 735, 538);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\u4FE1\u606F\u7BA1\u7406\u67E5\u8BE2");
		menuBar.add(mnNewMenu);
		
		JMenuItem bz = new JMenuItem("\u62A5\u7EB8");
		bz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Newspaper(table).setVisible(true); 
			}
		});
		mnNewMenu.add(bz);
		
		JMenuItem kh = new JMenuItem("\u5BA2\u6237");
		kh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UserF(table).setVisible(true); 
			}
		});
		mnNewMenu.add(kh);
		
		JMenuItem gys = new JMenuItem("\u4F9B\u5E94\u5546");
		gys.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new GysF(table).setVisible(true); 
			}
		});
		mnNewMenu.add(gys);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"ID", "\u4F9B\u5E94\u5546\u540D", "\u62A5\u7EB8\u540D", "\u5730\u533A", "\u7535\u8BDD\u53F7\u7801", "\u90AE\u4EF6"
			}
		));
		try {
			Gys.fresh(table);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scrollPane.setViewportView(table);
	}
}
