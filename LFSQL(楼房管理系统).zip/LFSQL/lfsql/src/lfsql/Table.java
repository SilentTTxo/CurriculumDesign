package lfsql;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Table extends JFrame {

	private JPanel contentPane;
	private JTable table;

	public Table() {
		setTitle("\u5B66\u751F\u5BBF\u820D\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 519);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu_1 = new JMenu("\u7BA1\u7406");
		menuBar.add(menu_1);
		
		JMenuItem lfg = new JMenuItem("\u697C\u623F\u7BA1\u7406");
		lfg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new lFC(table).setVisible(true); 
			}
		});
		menu_1.add(lfg);
		JMenuItem ssg = new JMenuItem("\u5BBF\u820D\u7BA1\u7406");
		ssg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Ssc(table).setVisible(true); 
			}
		});
		menu_1.add(ssg);
		
		JMenuItem ygg = new JMenuItem("\u5458\u5DE5\u7BA1\u7406");
		ygg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Ryc(table).setVisible(true); 
			}
		});
		menu_1.add(ygg);
		
		JMenuItem wpg = new JMenuItem("\u5BBF\u820D\u7269\u54C1\u7BA1\u7406");
		wpg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ItemC(table).setVisible(true); 
			}
		});
		menu_1.add(wpg);
		
		JMenuItem qcg = new JMenuItem("\u8FC1\u51FA\u7BA1\u7406");
		qcg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Go(table).setVisible(true); 
			}
		});
		menu_1.add(qcg);
		
		JMenu mnNewMenu = new JMenu("\u67E5\u8BE2\u6570\u636E");
		menuBar.add(mnNewMenu);
		
		JMenuItem cl = new JMenuItem("\u67E5\u8BE2\u4F4F\u5BBF\u697C\u4FE1\u606F");
		cl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					LF.fresh(table);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		});
		mnNewMenu.add(cl);
		
		JMenuItem css = new JMenuItem("\u67E5\u8BE2\u5BBF\u820D\u4FE1\u606F");
		css.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					SS.fresh(table);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		});
		mnNewMenu.add(css);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 704, 459);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
			},
			new String[] {
				"\u7BA1\u7406\u5458ID", "\u59D3\u540D"
			}
		));
		try {
			LF.fresh(table);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		scrollPane.setViewportView(table);
	}
}
