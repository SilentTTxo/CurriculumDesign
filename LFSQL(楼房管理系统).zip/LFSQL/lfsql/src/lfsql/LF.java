package lfsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LF {
	public String ID,Address,Name,c_man;
	LF(String id,String address,String name,String cman){
		ID = id;
		Address = address;
		Name = name;
		if(cman.equals("")) c_man = "1";
		else c_man = cman;
	}
	static void fresh(JTable jt) throws Exception{
		Object[][] tempp = null;
		SQL db = new SQL();
		try {
			ResultSet rs = db.Do("SELECT building.ID,building.NAME,building.ADDRESS,PERSON.NAME FROM BUILDING JOIN PERSON ON building.C_MAN = person.ID ");
			int i=0;
			while(rs.next()) i++;
			rs = db.Do("SELECT building.ID,building.NAME,building.ADDRESS,PERSON.NAME FROM BUILDING JOIN PERSON ON building.C_MAN = person.ID ");
			tempp = new Object[i][4];
			i=0;
			while(rs.next()){
				for(int y=0;y<4;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"\u697C\u623FID", "\u540D\u5B57", "\u697C\u623F\u5730\u5740", "\u7BA1\u7406\u4EBA\u5458"
				}
		));
	}
	static boolean add(LF temp){
		try {
			SQL db = new SQL();
			db.Se("INSERT INTO BUILDING VALUES (null,'"+temp.Name+"','"+temp.Address+"',"+temp.c_man+");");
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean del(String ID){
		try {
			SQL db = new SQL();
			db.Se("DELETE FROM BUILDING WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean update(LF temp){
		try {
			SQL db = new SQL();
			db.Se("UPDATE BUILDING SET NAME = '"+temp.Name+"',ADDRESS = '"+temp.Address+"',C_MAN = "+temp.c_man+" WHERE ID = "+temp.ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
}
