package lfsql;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class lFC extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField Name;
	private JTextField Address;
	private JTextField CID;
	private JTextField ID;

	public lFC(JTable table) {
		setTitle("\u697C\u623F\u7BA1\u7406");
		setBounds(100, 100, 273, 298);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u697C\u623F\u540D\u5B57\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(45, 26, 68, 15);
		contentPanel.add(lblNewLabel);
		
		Name = new JTextField();
		Name.setBounds(123, 23, 68, 21);
		contentPanel.add(Name);
		Name.setColumns(10);
		
		JLabel label = new JLabel("\u697C\u623F\u5730\u5740\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(45, 68, 68, 15);
		contentPanel.add(label);
		
		Address = new JTextField();
		Address.setColumns(10);
		Address.setBounds(123, 65, 68, 21);
		contentPanel.add(Address);
		
		JLabel lblid = new JLabel("\u7BA1\u7406\u5458ID\uFF1A");
		lblid.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid.setBounds(45, 114, 68, 15);
		contentPanel.add(lblid);
		
		CID = new JTextField();
		CID.setColumns(10);
		CID.setBounds(123, 111, 68, 21);
		contentPanel.add(CID);
		
		JLabel lblid_1 = new JLabel("\u697C\u623FID\uFF1A");
		lblid_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid_1.setBounds(45, 180, 68, 15);
		contentPanel.add(lblid_1);
		
		ID = new JTextField();
		ID.setColumns(10);
		ID.setBounds(123, 177, 68, 21);
		contentPanel.add(ID);
		
		JLabel lblNewLabel_1 = new JLabel("\u5220\u9664\u6216\u8005\u4FEE\u6539\u6570\u636E\u8BF7\u586B\u5165ID\uFF0C\u589E\u52A0\u4E0D\u586BID");
		lblNewLabel_1.setBounds(10, 156, 237, 15);
		contentPanel.add(lblNewLabel_1);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			
			JButton add = new JButton("\u589E\u52A0");
			add.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					LF temp = new LF("",Address.getText(),Name.getText(),CID.getText());
					if(LF.add(temp)) JOptionPane.showMessageDialog(null, "���ӳɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ�ܣ��������Աid,û�п��Բ���");
					try {
						LF.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			buttonPane.add(add);
			{
				JButton update = new JButton("\u4FEE\u6539");
				update.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						LF temp = new LF(ID.getText(),Address.getText(),Name.getText(),CID.getText());
						if(LF.update(temp)) JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
						else JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�����ID���߹���ԱID");
						try {
							LF.fresh(table);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				update.setActionCommand("OK");
				buttonPane.add(update);
				getRootPane().setDefaultButton(update);
			}
			{
				JButton del = new JButton("\u5220\u9664");
				del.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(LF.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
						else JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�����ID");
						try {
							LF.fresh(table);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				del.setActionCommand("Cancel");
				buttonPane.add(del);
			}
			
			JButton back = new JButton("\u8FD4\u56DE");
			back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			buttonPane.add(back);
		}
	}
}
