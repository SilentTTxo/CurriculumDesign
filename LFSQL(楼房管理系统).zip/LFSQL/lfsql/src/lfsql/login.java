package lfsql;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JPasswordField;
import java.awt.SystemColor;

public class login extends JFrame {

	private login me ;
	private JPanel contentPane;
	private JTextField user;
	private SQL db;	
	private ActionListener login = new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			try {
				boolean key=false;
				ResultSet rs = db.Do("SELECT * FROM LOGIN");
				while(rs.next()){
					if(rs.getString(2).trim().equals(user.getText())&&rs.getString(3).trim().equals(new String(password.getPassword()))){
						JOptionPane.showMessageDialog(null, "��½�ɹ�");
						System.out.println(rs.getString(1)+"  "+rs.getString(2));
						new Table().setVisible(true);
						me.dispose();
						key=true;
						break;
					}
				}
				if(!key){
					JOptionPane.showMessageDialog(null, "�˺��������");
					key=false;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, e.toString()+"\n�����ѻ�����");
				new Table().setVisible(true);
				me.dispose();
				e.printStackTrace();
			}
		}
	};
	private JPasswordField password;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws Exception 
	 */
	public login() throws Exception {
		me = this;
		setTitle("\u7BA1\u7406\u5458\u767B\u9646");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 309, 224);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		db = new SQL();
		
		JLabel label = new JLabel("\u7528\u6237\u540D");
		label.setBounds(44, 48, 49, 15);
		contentPane.add(label);
		
		user = new JTextField();
		user.setBounds(103, 46, 127, 18);
		contentPane.add(user);
		user.setColumns(10);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(56, 89, 37, 15);
		contentPane.add(label_1);
		
		JButton button = new JButton("\u767B\u9646");
		
		button.addActionListener(login);
		button.setBounds(103, 132, 95, 25);
		contentPane.add(button);
		
		password = new JPasswordField();
		password.setBounds(103, 86, 127, 21);
		contentPane.add(password);
	}
}
