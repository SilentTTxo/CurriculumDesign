package lfsql;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ryc extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField Name;
	private JTextField ID;

	public Ryc(JTable table) {
		setTitle("\u5458\u5DE5\u7BA1\u7406");
		setBounds(100, 100, 273, 172);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblid = new JLabel("\u59D3\u540D\uFF1A");
		lblid.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid.setBounds(25, 13, 68, 15);
		contentPanel.add(lblid);
		
		Name = new JTextField();
		Name.setColumns(10);
		Name.setBounds(103, 10, 79, 21);
		contentPanel.add(Name);
		
		JLabel lblid_1 = new JLabel("\u5458\u5DE5ID\uFF1A");
		lblid_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid_1.setBounds(36, 66, 68, 15);
		contentPanel.add(lblid_1);
		
		ID = new JTextField();
		ID.setColumns(10);
		ID.setBounds(114, 63, 68, 21);
		contentPanel.add(ID);
		
		JLabel lblNewLabel_1 = new JLabel("\u5220\u9664\u6216\u8005\u4FEE\u6539\u6570\u636E\u8BF7\u586B\u5165ID\uFF0C\u589E\u52A0\u4E0D\u586BID");
		lblNewLabel_1.setBounds(25, 38, 237, 15);
		contentPanel.add(lblNewLabel_1);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			
			JButton add = new JButton("\u589E\u52A0");
			add.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Ry temp = new Ry("",Name.getText());
					if(Ry.add(temp)) JOptionPane.showMessageDialog(null, "���ӳɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ��");
					try {
						Ry.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			buttonPane.add(add);
			{
				JButton update = new JButton("\u4FEE\u6539");
				update.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Ry temp = new Ry(ID.getText(),Name.getText());
						if(Ry.update(temp)) JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
						else JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�����ID");
						try {
							Ry.fresh(table);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				update.setActionCommand("OK");
				buttonPane.add(update);
				getRootPane().setDefaultButton(update);
			}
			{
				JButton del = new JButton("\u5220\u9664");
				del.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(Ry.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
						else JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�����ID");
						try {
							Ry.fresh(table);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				del.setActionCommand("Cancel");
				buttonPane.add(del);
			}
			
			JButton back = new JButton("\u8FD4\u56DE");
			back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			buttonPane.add(back);
		}
	}
}
