package lfsql;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Go extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField QSID;
	private JTextField LFID;
	private JTextField NAME;

	public Go(JTable table) {
		setTitle("\u8FC1\u51FA\u7BA1\u7406");
		setBounds(100, 100, 367, 208);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("\u5BDD\u5BA4ID\uFF1A");
			lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			lblNewLabel.setBounds(61, 10, 54, 15);
			contentPanel.add(lblNewLabel);
		}
		{
			QSID = new JTextField();
			QSID.setBounds(120, 7, 66, 21);
			contentPanel.add(QSID);
			QSID.setColumns(10);
		}
		{
			JButton btnNewButton = new JButton("\u653E\u9010\u8FD9\u4E2A\u5BDD\u5BA4");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if(SS.Go(QSID.getText())) JOptionPane.showMessageDialog(null, "���ųɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ��");
					try {
						SS.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			btnNewButton.setBounds(199, 6, 115, 23);
			contentPanel.add(btnNewButton);
		}
		{
			JLabel lblid = new JLabel("\u697C\u623FID\uFF1A");
			lblid.setHorizontalAlignment(SwingConstants.RIGHT);
			lblid.setBounds(61, 50, 54, 15);
			contentPanel.add(lblid);
		}
		{
			LFID = new JTextField();
			LFID.setColumns(10);
			LFID.setBounds(120, 47, 66, 21);
			contentPanel.add(LFID);
		}
		{
			JButton button = new JButton("\u9063\u6563\u8FD9\u4E2A\u697C\u623F");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if(SS.GoAhead(LFID.getText())) JOptionPane.showMessageDialog(null, "���ųɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ��");
					try {
						SS.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button.setBounds(199, 46, 115, 23);
			contentPanel.add(button);
		}
		{
			JLabel label = new JLabel("\u5C45\u4F4F\u8005\u540D\uFF1A");
			label.setHorizontalAlignment(SwingConstants.RIGHT);
			label.setBounds(42, 93, 73, 15);
			contentPanel.add(label);
		}
		{
			NAME = new JTextField();
			NAME.setColumns(10);
			NAME.setBounds(120, 90, 66, 21);
			contentPanel.add(NAME);
		}
		{
			JButton button = new JButton("\u6D41\u653E\u4ED6\uFF01");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if(SS.Goyou(NAME.getText())) JOptionPane.showMessageDialog(null, "���ųɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ��");
					try {
						SS.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button.setBounds(199, 89, 115, 23);
			contentPanel.add(button);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton cancelButton = new JButton("\u8FD4\u56DE");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
