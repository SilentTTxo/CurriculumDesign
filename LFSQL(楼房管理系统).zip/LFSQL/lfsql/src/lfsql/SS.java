package lfsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class SS {
	public String ID,No,Belong,Man;
	SS(String id,String no,String belong,String man){
		ID = id;
		No = no;
		Belong = belong;
		Man = man;
	}
	static void fresh(JTable jt) throws Exception{
		Object[][] tempp = null;
		SQL db = new SQL();
		try {
			ResultSet rs = db.Do("SELECT * FROM ROOM");
			int i=0;
			while(rs.next()) i++;
			rs = db.Do("SELECT * FROM ROOM");
			tempp = new Object[i][5];
			i=0;
			while(rs.next()){
				for(int y=0;y<5;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"\u5BBF\u820DID", "\u5BBF\u820D\u53F7", "\u6240\u5728\u697C\u623F","������Ʒ", "\u6240\u4F4F\u4EBA\u5458"
				}
		));
	}
	static boolean add(SS temp){
		try {
			SQL db = new SQL();
			db.Se("INSERT INTO ROOM VALUES (null,"+temp.Belong+","+temp.No+",NULL,'"+temp.Man+"')");
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean del(String ID){
		try {
			SQL db = new SQL();
			db.Se("DELETE FROM ROOM WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean update(SS temp){
		try {
			SQL db = new SQL();
			//System.out.println("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			db.Se("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean FItem(String ID,JTextArea jt){
		try {
			SQL db = new SQL();
			//System.out.println("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			ResultSet rs = db.Do("SELECT ITEM FROM ROOM WHERE ID = "+ID);
			rs.next();
			jt.setText(rs.getString(1));
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean SItem(String ID,JTextArea jt){
		try {
			SQL db = new SQL();
			//System.out.println("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			db.Se("UPDATE ROOM SET ITEM = '"+jt.getText()+"' WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean Go(String ID){
		try {
			SQL db = new SQL();
			//System.out.println("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			db.Se("UPDATE ROOM SET MAN = NULL WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean GoAhead(String ID){
		try {
			SQL db = new SQL();
			//System.out.println("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			db.Se("UPDATE ROOM SET MAN = NULL WHERE BELONG = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean Goyou(String name){
		try {
			SQL db = new SQL();
			//System.out.println("UPDATE ROOM SET NO = "+temp.No+",BELONG = "+temp.Belong+",MAN = '"+temp.Man+"' WHERE ID = "+temp.ID);
			ResultSet rs = db.Do("SELECT ID,MAN FROM ROOM WHERE MAN LIKE '%"+name+"%'");
			rs.next();
			String id = rs.getString(1);
			String data = rs.getString(2);
			String[] t = data.split("��");
			String gg = "";
			for(int i=0 ; i<t.length ; i++){
				if(!t[i].equals(name)){
					if(i!=0) gg+="��";
					gg+=t[i];
				}
			}
			db.Se("UPDATE ROOM SET MAN = '"+gg+"' WHERE ID = "+id);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
}
