package lfsql;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Ry {
	public String ID,Name;
	Ry(String id,String name){
		ID = id;
		Name = name;
	}
	static void fresh(JTable jt) throws Exception{
		Object[][] tempp = null;
		SQL db = new SQL();
		try {
			ResultSet rs = db.Do("SELECT * FROM person");
			int i=0;
			while(rs.next()) i++;
			rs = db.Do("SELECT * FROM person");
			tempp = new Object[i][2];
			i=0;
			while(rs.next()){
				for(int y=0;y<2;y++){
					tempp[i][y] = rs.getString(y+1);
				}
				i++;
			}
			db.Close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jt.setModel(new DefaultTableModel(
				tempp,
			new String[] {
					"\u7BA1\u7406\u5458ID", "\u59D3\u540D"
				}
		));
	}
	static boolean add(Ry temp){
		try {
			SQL db = new SQL();
			db.Se("INSERT INTO PERSON VALUES (null,'"+temp.Name+"')");
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean del(String ID){
		try {
			SQL db = new SQL();
			db.Se("DELETE FROM PERSON WHERE ID = "+ ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	static boolean update(Ry temp){
		try {
			SQL db = new SQL();
			System.out.println("UPDATE PERSON SET NAME = '"+temp.Name+"' WHERE ID = "+temp.ID);
			db.Se("UPDATE PERSON SET NAME = '"+temp.Name+"' WHERE ID = "+temp.ID);
			db.Close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
}
