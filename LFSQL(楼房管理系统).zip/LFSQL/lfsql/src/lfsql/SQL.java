package lfsql;


import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQL {
	private String driverName = "com.mysql.jdbc.Driver";//������������
	private String connectionUrl = "jdbc:mysql://localhost:3306/lfsql?useUnicode=true&characterEncoding=GBK";
	final String name = "root";    
    final String password = "";
	private Connection con;
	private Statement stmt ;
	SQL() throws Exception{
		Class.forName(driverName);
		con = DriverManager.getConnection(connectionUrl, name, password); 
        stmt = con.createStatement();
	}
	public void Close() throws SQLException{
		con.close();
	}
	public ResultSet Do(String sql) throws SQLException{
		return stmt.executeQuery(sql);
	}
	public ResultSet Do2(String sql) throws SQLException{
		return con.createStatement().executeQuery(sql);
	}
	public void Se(String sql) throws SQLException{
		stmt.execute(sql);
	}
}
