package lfsql;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ssc extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField No;
	private JTextField Belong;
	private JTextField Man;
	private JTextField ID;

	public Ssc(JTable table) {
		setTitle("\u5BBF\u820D\u7BA1\u7406");
		setBounds(100, 100, 273, 298);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5BDD\u5BA4\u53F7\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(45, 26, 68, 15);
		contentPanel.add(lblNewLabel);
		
		No = new JTextField();
		No.setBounds(123, 23, 68, 21);
		contentPanel.add(No);
		No.setColumns(10);
		
		JLabel label = new JLabel("\u6240\u5C5E\u697C\u623F\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(45, 68, 68, 15);
		contentPanel.add(label);
		
		Belong = new JTextField();
		Belong.setColumns(10);
		Belong.setBounds(123, 65, 68, 21);
		contentPanel.add(Belong);
		
		JLabel lblid = new JLabel("\u4EBA\u5458\uFF1A");
		lblid.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid.setBounds(24, 114, 68, 15);
		contentPanel.add(lblid);
		
		Man = new JTextField();
		Man.setColumns(10);
		Man.setBounds(102, 111, 130, 21);
		contentPanel.add(Man);
		
		JLabel lblid_1 = new JLabel("\u5BBF\u820DID\uFF1A");
		lblid_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblid_1.setBounds(45, 180, 68, 15);
		contentPanel.add(lblid_1);
		
		ID = new JTextField();
		ID.setColumns(10);
		ID.setBounds(123, 177, 68, 21);
		contentPanel.add(ID);
		
		JLabel lblNewLabel_1 = new JLabel("\u5220\u9664\u6216\u8005\u4FEE\u6539\u6570\u636E\u8BF7\u586B\u5165ID\uFF0C\u589E\u52A0\u4E0D\u586BID");
		lblNewLabel_1.setBounds(10, 156, 237, 15);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u8BF7\u7528\u9017\u53F7\u9694\u5F00\u4F8B\u5982\uFF1A\u5F20\u4E09\uFF0C\u674E\u56DB");
		lblNewLabel_2.setBounds(45, 93, 187, 15);
		contentPanel.add(lblNewLabel_2);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			
			JButton add = new JButton("\u589E\u52A0");
			add.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SS temp = new SS("",Belong.getText(),No.getText(),Man.getText());
					if(SS.add(temp)) JOptionPane.showMessageDialog(null, "���ӳɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ�ܣ�����¥��");
					try {
						SS.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			buttonPane.add(add);
			{
				JButton update = new JButton("\u4FEE\u6539");
				update.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SS temp = new SS(ID.getText(),No.getText(),Belong.getText(),Man.getText());
						if(SS.update(temp)) JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
						else JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�����ID");
						try {
							SS.fresh(table);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				update.setActionCommand("OK");
				buttonPane.add(update);
				getRootPane().setDefaultButton(update);
			}
			{
				JButton del = new JButton("\u5220\u9664");
				del.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(SS.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
						else JOptionPane.showMessageDialog(null, "ɾ��ʧ�ܣ�����ID");
						try {
							SS.fresh(table);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				del.setActionCommand("Cancel");
				buttonPane.add(del);
			}
			
			JButton back = new JButton("\u8FD4\u56DE");
			back.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			buttonPane.add(back);
		}
	}
}
