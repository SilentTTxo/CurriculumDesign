package lfsql;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ItemC extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField ID;
	private JTextArea Item;

	public ItemC(JTable table) {
		setTitle("\u5BBF\u820D\u7269\u54C1\u7BA1\u7406");
		setBounds(100, 100, 325, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5BBF\u820DID\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(35, 10, 54, 15);
		contentPanel.add(lblNewLabel);
		
		ID = new JTextField();
		ID.setBounds(99, 7, 79, 21);
		contentPanel.add(ID);
		ID.setColumns(10);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SS.FItem(ID.getText(), Item);
			}
		});
		btnNewButton.setBounds(188, 6, 93, 23);
		contentPanel.add(btnNewButton);
		
		Item = new JTextArea();
		Item.setBounds(22, 33, 277, 85);
		contentPanel.add(Item);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("\u63D0\u4EA4\u4FEE\u6539");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if(SS.SItem(ID.getText(), Item)) JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
						else JOptionPane.showMessageDialog(null, "�޸�ʧ��");
						try {
							SS.fresh(table);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("\u8FD4\u56DE");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
