import java.io.*;
import java.net.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import java.applet.Applet;

public class SocServer extends Thread{
	private ServerSocket server;
	private Socket socket;
	private BufferedReader is;
	private PrintWriter os;
	private BufferedReader sin;
	private SQL db;
	private JTextArea jta;
	private String Name;
	SocServer(JTextArea temp){
		jta = temp;
		try {
			db = new SQL();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void run() {
		try{
			 server=null;
			try{
				server=new ServerSocket(8888);
				}
			catch(Exception e) {
					System.out.println("can not listen to:"+e);
					}
			socket=null;
			try{
				System.out.println("wating!");
				socket=server.accept();
				System.out.println("ok!");
				}
			catch(Exception e) {
					System.out.println("Error."+e);
					}
			is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
			os=new PrintWriter(socket.getOutputStream());
			sin=new BufferedReader(new InputStreamReader(System.in));
			}
		catch(Exception e) {
			System.out.println("Error:"+e);
			}
		try {
			while(true){
				String temp = is.readLine();
				if(temp!=null){
					String[] ss = temp.split(",") ; 
					if(ss[0].equals("login")){
						try {
							boolean key=false;
							ResultSet rs = db.Do("SELECT * FROM LOGIN");
							while(rs.next()){
								if(rs.getString(2).equals(ss[1])&&rs.getString(3).equals(ss[2])){
									send("login right!");
									Name = ss[1];
									key=true;
									break;
								}
							}
							if(!key){
								send("oh-NO!");
								key=false;
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if(ss[0].equals("RIG")){
						try {
							db.Se("INSERT INTO LOGIN VALUES (NULL,'"+ss[1]+"','"+ss[2]+"')");
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else {
						String tempp = jta.getText();
						jta.setText(tempp+="\n"+Name+":"+temp);
					}
					System.out.println("Client:"+temp);
				}
				}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	public void Close() throws IOException{
		os.close();
		is.close();
		socket.close();
		server.close();
	}
	public void send(String temp){
		os.println(temp);
		os.flush();
	}
}