import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class User extends JFrame {

	private JPanel contentPane;
	private JTextField ID;
	private JTextField Name;
	private JLabel label;
	private JTextField Password;
	private JLabel label_1;
	private JButton Add;
	private JButton Del;
	private JScrollPane scrollPane;
	private JTable table;
	private user us;

	public User() {
		us = new user("","","");
		setTitle("\u7528\u6237\u7BA1\u7406");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 492, 375);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setHorizontalAlignment(SwingConstants.RIGHT);
		lblId.setBounds(-17, 13, 54, 15);
		contentPane.add(lblId);
		
		ID = new JTextField();
		ID.setBounds(47, 10, 66, 21);
		contentPane.add(ID);
		ID.setColumns(10);
		
		Name = new JTextField();
		Name.setColumns(10);
		Name.setBounds(160, 10, 66, 21);
		contentPane.add(Name);
		
		label = new JLabel("\u59D3\u540D:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(96, 13, 54, 15);
		contentPane.add(label);
		
		Password = new JTextField();
		Password.setColumns(10);
		Password.setBounds(268, 10, 59, 21);
		contentPane.add(Password);
		
		label_1 = new JLabel("\u5BC6\u7801:");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(204, 13, 54, 15);
		contentPane.add(label_1);
		
		Add = new JButton("\u6DFB\u52A0");
		Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(us.add(new user(ID.getText(),Name.getText(),Password.getText()))) JOptionPane.showMessageDialog(null, "���ӳɹ�");
					else JOptionPane.showMessageDialog(null, "����ʧ��");
					try {
						us.fresh(table);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});
		Add.setBounds(337, 8, 66, 25);
		contentPane.add(Add);
		
		Del = new JButton("\u5220\u9664");
		Del.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(us.del(ID.getText())) JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
				else JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
				try {
					us.fresh(table);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Del.setBounds(413, 8, 71, 25);
		contentPane.add(Del);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 38, 484, 310);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"ID", "\u7528\u6237\u540D", "\u5BC6\u7801"
			}
		));
		us.fresh(table);
		scrollPane.setViewportView(table);
	}
	class user {
		String ID,Name,Password;
		user(String id,String name,String password){
			ID = id;
			Name = name;
			Password = password;
		}
		public void fresh(JTable jt){
			Object[][] tempp = null;
			try {
				SQL db = new SQL();
				ResultSet rs = db.Do("SELECT * FROM LOGIN");
				int i=0;
				while(rs.next()) i++;
				rs = db.Do("SELECT * FROM LOGIN");
				tempp = new Object[i][3];
				i=0;
				while(rs.next()){
					for(int y=0;y<3;y++){
						tempp[i][y] = rs.getString(y+1);
					}
					i++;
				}
				db.Close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jt.setModel(new DefaultTableModel(
					tempp,
				new String[] {
						"�û�ID", "�û���", "����"
					}
			));
		}
		public boolean add(user temp){
			try {
				SQL db = new SQL();
				db.Se("INSERT INTO LOGIN VALUES (null,'"+temp.Name+"','"+temp.Password+"')");
				db.Close();
				return true;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}
		public boolean del(String ID){
			try {
				SQL db = new SQL();
				db.Se("DELETE FROM LOGIN WHERE ID = "+ ID);
				db.Close();
				return true;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}
	}
}
