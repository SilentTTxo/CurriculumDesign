import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Table extends JFrame {

	private JPanel contentPane;
	private JTextField inputt;
	private SocServer ss;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Table frame = new Table();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Table() {
		setTitle("\u670D\u52A1\u7AEF ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 334, 423);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\u7528\u6237");
		menuBar.add(mnNewMenu);
		
		JMenuItem user = new JMenuItem("\u7528\u6237\u7BA1\u7406");
		user.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new User().setVisible(true);
			}
		});
		mnNewMenu.add(user);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(0, 0, 311, 326);
		contentPane.add(textArea);
		ss = new SocServer(textArea);
		ss.start();
		
		inputt = new JTextField();
		inputt.setBounds(10, 334, 219, 23);
		contentPane.add(inputt);
		inputt.setColumns(10);
		
		JButton send = new JButton("\u53D1\u9001");
		send.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ss.send("Server:"+inputt.getText());
				String tempp = textArea.getText();
				textArea.setText(tempp+="\n"+"Server:"+inputt.getText());
			}
		});
		send.setBounds(239, 333, 72, 25);
		contentPane.add(send);
	}
}
