import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class RG extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField username;
	private SocCilent sc;
	private JPasswordField password;
	
	public RG(SocCilent tp) {
		sc = tp; 
		setTitle(" \u6CE8\u518C\u7528\u6237");
		setBounds(100, 100, 295, 202);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(52, 24, 54, 15);
		contentPanel.add(lblNewLabel);
		
		username = new JTextField();
		username.setBounds(119, 21, 90, 21);
		contentPanel.add(username);
		username.setColumns(10);
		
		JLabel label = new JLabel("\u5BC6\u7801\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(52, 67, 54, 15);
		contentPanel.add(label);
		
		password = new JPasswordField();
		password.setBounds(118, 64, 91, 18);
		contentPanel.add(password);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("\u6CE8\u518C");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						sc.send("RIG,"+username.getText()+","+password.getText());
						JOptionPane.showMessageDialog(null, "ע��ɹ���");
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("\u8FD4\u56DE");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
