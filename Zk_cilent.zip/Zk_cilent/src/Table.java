import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Table extends JFrame {

	private JPanel contentPane;
	private JTextField mes;
	private SocCilent sc;
	private String name;

	public Table(SocCilent sc1,String name1) {
		sc = sc1;
		sc.Name =name1;
		name = name1;
		setTitle("\u5BA2\u6237\u7AEF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 343, 382);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea jta = new JTextArea();
		jta.setBounds(10, 10, 315, 297);
		contentPane.add(jta);
		sc.jta = jta;
		
		mes = new JTextField();
		mes.setBounds(10, 317, 235, 21);
		contentPane.add(mes);
		mes.setColumns(10);
		
		JButton button = new JButton("\u53D1\u9001");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sc.send(mes.getText());
				String tempp = jta.getText();
				jta.setText(tempp+="\n"+name+":"+mes.getText());
			}
		});
		button.setBounds(255, 315, 70, 25);
		contentPane.add(button);
	}

}
