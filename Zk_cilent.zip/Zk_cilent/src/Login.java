import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;


public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField username;
	private SocCilent sc;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		sc = new SocCilent();
		sc.start();
		setTitle("\u7528\u6237\u767B\u5F55");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 267, 189);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(42, 30, 54, 15);
		contentPane.add(lblNewLabel);
		
		username = new JTextField();
		username.setBounds(105, 27, 93, 21);
		contentPane.add(username);
		username.setColumns(10);
		
		JLabel label = new JLabel("\u5BC6\u7801\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(42, 73, 54, 15);
		contentPane.add(label);
		
		JButton button = new JButton("\u767B\u9646");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sc.send("login,"+username.getText()+","+password.getText());
				int i=0;
				while(true){
					if (sc.key == 0) {
						
					}
					if(sc.key==1){
						JOptionPane.showMessageDialog(null, "�˺��������");
						sc.key=0;
						break;
					}
					if(sc.key==2){
						new Table(sc,username.getText()).setVisible(true);
						dispose();
						break;
					}
				}
			}
		});
		button.setBounds(42, 115, 95, 25);
		contentPane.add(button);
		
		password = new JPasswordField();
		password.setBounds(105, 70, 93, 21);
		contentPane.add(password);
		
		JButton righst = new JButton("\u6CE8\u518C");
		righst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new RG(sc).setVisible(true);
			}
		});
		righst.setBounds(147, 116, 93, 23);
		contentPane.add(righst);
	}
}
