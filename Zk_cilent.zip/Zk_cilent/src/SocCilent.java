import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JTextArea;
import javax.swing.JTextField;


public class SocCilent extends Thread{
	private Socket socket;
	private BufferedReader sin;
	private PrintWriter os;
	private BufferedReader is;
	public int key = 0;
	public JTextArea jta;
	public String Name;
	SocCilent(){
		try{
			System.out.println("yo"); 
			Socket socket=new Socket("localhost",8888);
			sin=new BufferedReader(new InputStreamReader(System.in));
			os=new PrintWriter(socket.getOutputStream());
			is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void run() {
		try {
			while(true){
				String temp = is.readLine();
				if(temp!=null){
					if(temp.equals("oh-NO!")){
						key = 1;
					}
					else if(temp.equals("login right!")){
						key = 2;
					}
					else if(key == 2){
						String tempp = jta.getText();
						jta.setText(tempp+="\n"+temp);
					}
				}
				}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	public void Close() throws IOException{
		os.close();
		is.close();
		socket.close();
	}
	public void send(String temp){
		os.println(temp);
		os.flush();
	}
}
